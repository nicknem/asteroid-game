In our game, bullets:

Are small circles
Move at a constant speed in a straight line
Split up asteroids when they collide with them
Are spawned by player input (spacebar) and move in the direction the player is fa

Create a new shot class
- inherits from CircleShape(x, y, radius)
- calls the parents constructor to get x, y and radius
- sets the radius to SHOT_RADIUS


The problem I have: 
- shot object is created, but isn't drawn to screen


Every second:
- the player.update() method is called
- if the space bar is pressed:
    the player.shoot()method is called
    it creates a new Shot obect with a position.x, position.y and a SHOT RADIUS --> check
    it gets and updates the shot.velocity (see later)